"""Internal JMComicReader service modules."""
