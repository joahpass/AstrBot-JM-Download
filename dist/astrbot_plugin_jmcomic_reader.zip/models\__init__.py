"""Internal JMComicReader data modules."""
