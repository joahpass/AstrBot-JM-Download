"""Internal JMComicReader data modules."""
