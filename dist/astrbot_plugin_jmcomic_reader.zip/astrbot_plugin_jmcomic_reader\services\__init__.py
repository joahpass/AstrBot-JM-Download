"""Internal JMComicReader service modules."""
